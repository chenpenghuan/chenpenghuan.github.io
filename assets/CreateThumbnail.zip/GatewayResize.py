import os
import boto3
import botocore
import PIL
from PIL import Image
from io import BytesIO
import urllib.parse

s3 = boto3.resource('s3')
tmp = 'tmp/'

def resize_image(bucket_domain, bucket_name, key, size):
    resized_key = '{tmp}{size}_{key}'.format(tmp=tmp, size=size, key=key)
    size_split = size.split('x')
    try:
        #检查压缩文件是否存在，如果存在直接返回
        s3.Object(bucket_name=bucket_name, key=resized_key).load()
        return "https://{domain}/{resized_key}".format(domain=bucket_domain, resized_key=resized_key)
    except Exception:
        obj = s3.Object(bucket_name=bucket_name, key=key)
        obj_body = obj.get()['Body'].read()
        img = Image.open(BytesIO(obj_body))
        img = img.resize((int(size_split[0]), int(size_split[1])), PIL.Image.ANTIALIAS)
        buffer = BytesIO()
        img.convert('RGB').save(buffer, 'JPEG')
        buffer.seek(0)
        obj = s3.Object(bucket_name=bucket_name, key=resized_key)
        obj.put(Body=buffer, ContentType='image/jpeg')
        return "https://{domain}/{resized_key}".format(domain=bucket_domain, resized_key=resized_key)


def lambda_handler(event, context):
    key = event['queryStringParameters'].get('key', None)
    key = urllib.parse.unquote(key)
    size = event['queryStringParameters'].get('size', None)
    bucket_domain = os.environ['BUCKET_DOMAIN']
    bucket_name = os.environ['BUCKET_NAME']

    image_s3_url = resize_image(bucket_domain, bucket_name, key, size)

    return {
        'statusCode': 301,
        'body': image_s3_url
    }
