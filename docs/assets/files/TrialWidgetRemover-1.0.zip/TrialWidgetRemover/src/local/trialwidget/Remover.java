package local.trialwidget;

import com.intellij.ide.AppLifecycleListener;
import com.intellij.openapi.actionSystem.ActionManager;

import java.util.List;

public final class Remover implements AppLifecycleListener {
    @Override
    public void appFrameCreated(List<String> commandLineArgs) {
        removeTrialWidget();
    }

    @Override
    public void appStarted() {
        removeTrialWidget();
    }

    private static void removeTrialWidget() {
        ActionManager.getInstance().unregisterAction("TrialStateWidget");
    }
}