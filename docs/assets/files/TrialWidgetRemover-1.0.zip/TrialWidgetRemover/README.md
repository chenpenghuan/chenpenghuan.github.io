# Trial Widget Remover — 使用说明

隐藏 JetBrains IDE 右上角的 "Unlock Ultimate" 按钮(IDEA 未订阅、以免费模式运行时出现)。

## 背景

该按钮由 IDEA 平台内部模块 `intellij.platform.trialPromotion.idesWithFreeTier` 中的 `TrialStateWidget` 提供:

- 硬编码注册到主工具栏右侧(`MainToolbarRight`);
- 实现了 `com.intellij.ide.ui.customization.NonCustomizableAction`,所以「Customize Toolbar」无法移除;
- 没有设置项或 Registry 开关(`TrialStateService.isEnabled()` 恒为 true)。

官方未提供隐藏方式(YouTrack: IDEA-384401 / IJPL-222323)。本插件在 IDE 启动时反注册该 Action 来隐藏按钮,与 IDE 内部禁用该组件使用的是同一套机制,不修改 IDE 安装包。

## 包内容

`TrialWidgetRemover-1.0.zip`

```
TrialWidgetRemover/
├── lib/trial-widget-remover.jar   # 插件本体
├── src/                           # 源码,便于重新构建
│   ├── local/trialwidget/Remover.java
│   └── plugin.xml
└── README.md
```

## 安装

### 方式一:IDE 内安装(推荐)

1. Settings / Preferences → Plugins
2. 点击齿轮 ⚙️ → Install Plugin from Disk…
3. 选择 `TrialWidgetRemover-1.0.zip`
4. Apply / OK 后重启 IDE

### 方式二:手动安装

把 zip 解压出的 `TrialWidgetRemover` 整个目录放到:

```
~/Library/Application Support/JetBrains/<产品及版本>/plugins/
```

例如 IDEA Ultimate 2026.3 对应 `IntelliJIdea2026.3`。重启 IDE 生效。

## 验证

重启后右上角 "Unlock Ultimate" 按钮应消失。可在 `Help → Show Log in Finder` 打开的 `idea.log` 中确认插件加载:

```
Loaded custom plugins: ... Trial Widget Remover (local.trial.widget.remover, 1.0), ...
```

## 卸载

- IDE 内:Settings → Plugins → Installed → Trial Widget Remover → Uninstall → 重启;
- 或直接删除插件目录 `plugins/TrialWidgetRemover/`。

卸载后按钮恢复显示。

## 原理

插件注册 `AppLifecycleListener`,在 IDE 启动时执行:

```java
ActionManager.getInstance().unregisterAction("TrialStateWidget");
```

## 源码与重新构建

源码位于插件目录 `src/`。重新构建(macOS,以 IntelliJ IDEA Ultimate 2026.3 为例):

```bash
cd TrialWidgetRemover
JBR="/Applications/IntelliJ IDEA.app/Contents/jbr/Contents/Home"
mkdir -p build/classes build/stage/META-INF
"$JBR/bin/javac" -cp "/Applications/IntelliJ IDEA.app/Contents/lib/*" \
  -d build/classes src/local/trialwidget/Remover.java
cp -R build/classes/. build/stage/
cp src/plugin.xml build/stage/META-INF/plugin.xml
jar --create --file build/trial-widget-remover.jar -C build/stage .
```

把生成的 `build/trial-widget-remover.jar` 覆盖到 `lib/` 即可。

## 注意事项

- 本插件只隐藏推广按钮,不改变授权状态,Ultimate 功能仍然不可用;
- 已在 IntelliJ IDEA Ultimate 2026.3(macOS)验证加载成功;
- 其它带免费模式的 JetBrains IDE(如 WebStorm、Rider 等)理论上同样适用,未逐一验证;
- IDE 大版本升级后插件一般随配置目录迁移;若按钮重新出现,通常是内部 Action ID 变化,需要按上文重新适配;
- 如果在 Settings → Plugins 中禁用本插件,按钮会恢复显示。