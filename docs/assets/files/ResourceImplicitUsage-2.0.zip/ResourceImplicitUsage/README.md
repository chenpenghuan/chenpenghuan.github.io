# Resource Implicit Usage — 使用说明

在 IntelliJ IDEA Community / OSS 版中,让「注入且被使用」的 Spring bean 类不再被 `Unused declaration` 误报,同时保留真正未使用的注入提示。

## 行为

| 场景 | 结果 |
|---|---|
| `@Resource` / `@Autowired` / `@Inject` 注入的字段**被使用** | 对应的 bean 实现类不再提示 "Class is never used" |
| 注入字段**没有被使用** | 字段和 bean 类照常提示 `Unused declaration` |
| bean 类没有被任何「已使用的注入点」引用 | 照常提示,不会被豁免 |

- 支持元注解(例如自定义注解标注了 `@Service`)
- 判断结果按类缓存,PSI 修改后自动失效

## 包内容

```
ResourceImplicitUsage/
├── lib/resource-implicit-usage.jar   # 插件本体
├── src/                              # 源码,便于重新构建
│   ├── local/resourceusage/ResourceImplicitUsageProvider.java
│   └── plugin.xml
└── README.md                         # 本文档
```

## 安装

### 方式一:IDE 内安装(推荐)

1. `Settings → Plugins → ⚙️ → Install Plugin from Disk…`
2. 选择 `ResourceImplicitUsage-2.0.zip`
3. Apply / OK 后重启 IDE

### 方式二:手动安装

把 zip 解压出的 `ResourceImplicitUsage` 目录放到:

```
~/Library/Application Support/JetBrains/<产品及版本>/plugins/
```

例如 OSS 2026.3 对应 `IdeaIC2026.3`。重启 IDE 生效。

## 验证

重启后可在 `Help → Show Log in Finder` 打开的 `idea.log` 中确认:

```
Loaded custom plugins: ... Resource Implicit Usage (local.resource.implicit.usage, 2.0), ...
```

代码效果:

- 之前被误报的 bean 实现类不再显示 "never used";
- 未被使用的 `@Resource` 字段仍然显示 `Unused declaration`。

## 卸载

`Settings → Plugins → Installed → Resource Implicit Usage → Uninstall`,或直接删除插件目录 `plugins/ResourceImplicitUsage/`。

## 原理

注册 `com.intellij.implicitUsageProvider` 扩展点:

1. 对标注了 `@Service` / `@Component` / `@Repository` / `@Controller` 的类;
2. 搜索其类型(含父类/接口)对应的注入字段(`javax/jakarta.annotation.Resource`、Spring `@Autowired`、`javax/jakarta.inject.Inject`);
3. 只有当某个注入字段**存在实际引用(被使用)** 时,才把 bean 类标记为隐式使用;
4. 字段本身不做任何隐式标记,因此未使用的注入仍会被 `Unused declaration` 提示。

## 限制

- 只覆盖**字段注入**;构造器注入、Setter 注入未覆盖;
- `@Controller` / `@Configuration` 等入口类未做特殊处理(如被误报可反馈补充);
- 注入注解必须是 `javax.annotation.Resource` / `jakarta.annotation.Resource` 或 Spring 的 `@Autowired` / `@Inject`;
- 不提供 Spring 的其它功能(Bean 跳转、配置提示、依赖检查等),只解决 "unused" 误报。

## 重新构建

以 macOS、IntelliJ IDEA OSS 2026.3 为例:

```bash
cd ResourceImplicitUsage
JBR="/Applications/IntelliJ IDEA OSS.app/Contents/jbr/Contents/Home"
CP=$(find "/Applications/IntelliJ IDEA OSS.app/Contents" -name '*.jar' -print | tr '\n' ':')
mkdir -p build/classes build/stage/META-INF
"$JBR/bin/javac" -cp "$CP" -d build/classes \
  src/local/resourceusage/ResourceImplicitUsageProvider.java
cp -R build/classes/. build/stage/
cp src/plugin.xml build/stage/META-INF/
jar --create --file build/resource-implicit-usage.jar -C build/stage .
```

把生成的 `build/resource-implicit-usage.jar` 覆盖到 `lib/` 即可。

## 兼容性

- 适用:IntelliJ IDEA Community / OSS 2026.2+(`since-build=262`);
- 本地验证版本:`IntelliJ IDEA OSS 2026.3`(IC-263.7307.200)。