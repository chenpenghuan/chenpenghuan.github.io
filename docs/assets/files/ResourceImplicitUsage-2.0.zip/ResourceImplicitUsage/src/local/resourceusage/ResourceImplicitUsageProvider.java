package local.resourceusage;

import com.intellij.codeInsight.MetaAnnotationUtil;
import com.intellij.codeInsight.daemon.ImplicitUsageProvider;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiCompiledElement;
import com.intellij.psi.PsiElement;
import com.intellij.psi.PsiField;
import com.intellij.psi.PsiFile;
import com.intellij.psi.PsiMethod;
import com.intellij.psi.PsiReference;
import com.intellij.psi.PsiTypeElement;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.psi.search.searches.ReferencesSearch;
import com.intellij.psi.util.CachedValueProvider;
import com.intellij.psi.util.CachedValuesManager;
import com.intellij.psi.util.PsiModificationTracker;

import java.util.ArrayList;
import java.util.List;

public final class ResourceImplicitUsageProvider implements ImplicitUsageProvider {

    private static final List<String> INJECTION_ANNOTATIONS = List.of(
            "javax.annotation.Resource",
            "jakarta.annotation.Resource",
            "org.springframework.beans.factory.annotation.Autowired",
            "javax.inject.Inject",
            "jakarta.inject.Inject"
    );

    private static final List<String> COMPONENT_ANNOTATIONS = List.of(
            "org.springframework.stereotype.Service",
            "org.springframework.stereotype.Component",
            "org.springframework.stereotype.Repository",
            "org.springframework.stereotype.Controller"
    );

    @Override
    public boolean isImplicitUsage(PsiElement element) {
        if (!(element instanceof PsiClass)) {
            return false;
        }
        PsiClass beanClass = (PsiClass) element;
        if (beanClass.isInterface() || beanClass.isAnnotationType() || beanClass.isEnum()) {
            return false;
        }
        if (!MetaAnnotationUtil.isMetaAnnotated(beanClass, COMPONENT_ANNOTATIONS)) {
            return false;
        }
        return CachedValuesManager.getCachedValue(beanClass, () ->
                CachedValueProvider.Result.create(
                        isInjectedAndUsed(beanClass),
                        PsiModificationTracker.MODIFICATION_COUNT));
    }

    @Override
    public boolean isImplicitRead(PsiElement element) {
        return false;
    }

    @Override
    public boolean isImplicitWrite(PsiElement element) {
        return false;
    }

    private static boolean isInjectedAndUsed(PsiClass beanClass) {
        Project project = beanClass.getProject();
        GlobalSearchScope scope = GlobalSearchScope.projectScope(project);

        List<PsiClass> candidateTypes = new ArrayList<>();
        candidateTypes.add(beanClass);
        collectSupertypes(beanClass, candidateTypes);

        for (PsiClass candidate : candidateTypes) {
            if (candidate instanceof PsiCompiledElement) {
                continue;
            }
            for (PsiReference reference : ReferencesSearch.search(candidate, scope, false)) {
                PsiField injectionField = findInjectionTypeField(reference.getElement());
                if (injectionField == null
                        || !MetaAnnotationUtil.isMetaAnnotated(injectionField, INJECTION_ANNOTATIONS)) {
                    continue;
                }
                if (ReferencesSearch.search(injectionField, scope, false).findFirst() != null) {
                    return true;
                }
            }
        }
        return false;
    }

    private static void collectSupertypes(PsiClass psiClass, List<PsiClass> out) {
        for (PsiClass superType : psiClass.getSupers()) {
            if (!out.contains(superType)) {
                out.add(superType);
                collectSupertypes(superType, out);
            }
        }
    }

    private static PsiField findInjectionTypeField(PsiElement referenceElement) {
        PsiElement current = referenceElement;
        boolean throughTypeElement = false;
        while (current != null) {
            if (current instanceof PsiTypeElement) {
                throughTypeElement = true;
            }
            if (current instanceof PsiField) {
                return throughTypeElement ? (PsiField) current : null;
            }
            if (current instanceof PsiMethod || current instanceof PsiClass || current instanceof PsiFile) {
                return null;
            }
            current = current.getParent();
        }
        return null;
    }
}